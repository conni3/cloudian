---
title: Week 1 - Day 1
date: 2025-05-19
showTableOfContents: true
tags:
  - calas
  - learning_log
showHeadingAnchors: true
---
This was my first day of the internship. We started the day with a meeting where all the CALAS members gathered and some were sharing their progress on their current research. I was able to grasp the general meaning but couldn't understand the finer details. 

After that, I introduced myself to the members there. It was nice meeting them. 
## Activities  
- Setting up Vitis
- planning schedule
- defining objectives and key deliverables
- Collect PYNQ-Z2

## Key learnings